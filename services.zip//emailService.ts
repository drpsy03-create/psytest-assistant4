import emailjs from "emailjs-com";
import { EMAIL_CONFIG } from "../config/email";
import {
  getEnvVar,
  getEnvironmentInfo,
} from "../utils/envUtils";

// EmailJS конфигурация с безопасным доступом к переменным окружения
const EMAIL_SERVICE_ID = "service_knq1zwz";
const EMAIL_TEMPLATE_ID = "template_fi8fxvv";
const EMAIL_USER_ID = "HDYwq3aKC9JqMR9vD";

interface Doctor {
  id: string;
  email: string;
  name: string;
  specialty?: string;
  clinic?: string;
  registrationDate: string;
  verificationCode?: string;
}

interface EmailTemplateParams {
  to_email: string;
  to_name: string;
  verification_code: string;
  doctor_name: string;
  doctor_specialty: string;
  doctor_clinic: string;
  registration_date: string;
  from_name: string;
  reply_to: string;
}

class EmailService {
  private initialized = false;

  // Инициализация EmailJS
  init() {
    if (!this.initialized) {
      try {
        console.log("🔧 Инициализация EmailJS...");
        console.log("📧 Service ID:", EMAIL_SERVICE_ID);
        console.log("📄 Template ID:", EMAIL_TEMPLATE_ID);
        console.log(
          "🔑 User ID:",
          EMAIL_USER_ID.substring(0, 8) + "...",
        );

        emailjs.init(EMAIL_USER_ID);
        this.initialized = true;
        console.log("✅ EmailJS инициализирован успешно");
      } catch (error) {
        console.error(
          "❌ Ошибка инициализации EmailJS:",
          error,
        );
        throw error;
      }
    }
  }

  // Отправка email с кодом подтверждения
  async sendVerificationEmail(
    doctor: Doctor,
    isResend = false,
  ): Promise<{ success: boolean; error?: string }> {
    try {
      this.init();

      const templateParams: EmailTemplateParams = {
        to_email: doctor.email,
        to_name: doctor.name,
        verification_code: doctor.verificationCode || "000000",
        doctor_name: doctor.name,
        doctor_specialty: doctor.specialty || "Не указана",
        doctor_clinic: doctor.clinic || "Не указана",
        registration_date: new Date(
          doctor.registrationDate,
        ).toLocaleDateString("ru-RU"),
        from_name: "PsyTest Assistant",
        reply_to: "noreply@psytest.com",
      };

      console.log(
        `${isResend ? "Повторная отправка" : "Отправка"} email на ${doctor.email}`,
      );
      console.log("Параметры шаблона:", templateParams);

      const response = await emailjs.send(
        EMAIL_SERVICE_ID,
        EMAIL_TEMPLATE_ID,
        templateParams,
      );

      console.log("✅ Email успешно отправлен:", response);

      return { success: true };
    } catch (error) {
      console.error("❌ Ошибка отправки email:", error);
      return {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Неизвестная ошибка отправки email",
      };
    }
  }

  // Отправка email для восстановления пароля
  async sendPasswordResetEmail(
    email: string,
    resetLink: string,
  ): Promise<{ success: boolean; error?: string }> {
    try {
      this.init();

      const templateParams = {
        to_email: email,
        reset_link: resetLink,
        from_name: "PsyTest Assistant",
        reply_to: "noreply@psytest.com",
      };

      const response = await emailjs.send(
        EMAIL_SERVICE_ID,
        "template_password_reset", // Отдельный шаблон для сброса пароля
        templateParams,
      );

      console.log(
        "✅ Email восстановления пароля отправлен:",
        response,
      );
      return { success: true };
    } catch (error) {
      console.error(
        "❌ Ошибка отправки email восстановления:",
        error,
      );
      return {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Ошибка отправки email восстановления",
      };
    }
  }

  // Проверка доступности сервиса
  async testConnection(): Promise<{
    success: boolean;
    error?: string;
  }> {
    try {
      this.init();

      const testParams = {
        to_email: "test@example.com",
        test_message: "Тест подключения к EmailJS",
        from_name: "PsyTest Assistant",
      };

      // Используем специальный тестовый шаблон или основной
      await emailjs.send(
        EMAIL_SERVICE_ID,
        EMAIL_TEMPLATE_ID,
        testParams,
      );

      return { success: true };
    } catch (error) {
      console.error(
        "❌ Ошибка тестирования соединения:",
        error,
      );
      return {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Ошибка подключения к email сервису",
      };
    }
  }

  // Проверка конфигурации EmailJS
  checkConfiguration(): {
    isValid: boolean;
    message: string;
    details: any;
  } {
    const config = EMAIL_CONFIG.getStatus();

    return {
      isValid: config.configured,
      message: config.message,
      details: {
        serviceId:
          EMAIL_SERVICE_ID === EMAIL_CONFIG.SERVICE_ID
            ? "demo"
            : "configured",
        templateId:
          EMAIL_TEMPLATE_ID === EMAIL_CONFIG.TEMPLATE_ID
            ? "demo"
            : "configured",
        userId:
          EMAIL_USER_ID === EMAIL_CONFIG.USER_ID
            ? "demo"
            : "configured",
        environment: getEnvironmentInfo().type,
      },
    };
  }
}

// Экспортируем единственный экземпляр
export const emailService = new EmailService();
export default emailService;